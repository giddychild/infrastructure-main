# Introduction

In today's rapidly evolving technological landscape, the demand for agility, scalability, and reliability in infrastructure management has never been greater. Many organizations are turning to Infrastructure-as-Code (IaC) to meet these demands as a foundational practice for managing and provisioning their infrastructure.

IaC is a methodology that allows infrastructure to be defined and managed using code. It enables development teams to automate infrastructure resource provisioning, configuration, and management through machine-readable definition files. This approach brings numerous benefits to organizations across various industries, revolutionizing how infrastructure is deployed and maintained.

In the Texas Water Development Board (TWDB) infrastructure modernization project, we focused on decoupling infrastructure modules by separating each primary cloud service into a dedicated Terraform module, e.g., Virtual Private Network (VPC). This approach allowed us to implement deployment steps in the specified order and explicitly set module interdependency.

There are two main technologies used across the project: **Terraform** and **Terragrunt**. Terraform is an open-source Infrastructure-as-Code (IaC) tool that allows users to define and provision infrastructure resources using a declarative configuration language (Hashicorp Configuration Language HCL). By utilizing a declarative approach, Terraform ensures that infrastructure configurations are described consistently and reproducibly. At the same time, its state management capabilities track changes and maintain the desired state of infrastructure resources.

Terragrunt is a thin wrapper for Terraform that provides additional features and enhancements to simplify the management of Terraform configurations. It aims to address common challenges Terraform users face, such as code duplication, configuration drift, and state management. 

Terragrunt offers remote state management, configuration templating, and automatic dependency management between Terraform modules. It also facilitates best practices for managing infrastructure code by enforcing a consistent directory structure and configuration file layout. Overall, Terragrunt complements Terraform by providing a more streamlined and scalable approach to managing infrastructure as code.

# Project structure

## Architecture Drawing TBD 

There are following directories in the project:
### infra-live
Includes Terragrunt file used to run specified environment from root folder `terragrunt.hcl`. Check this file for initial setup parameters such as working environment, AWS account, AWS region, S3 bucket and Dynamo DB state table. There will be also directories dedicated to specific environment e.g. "production", "sandbox", "dev" that will be used to run Terragrunt intended for specific environment or AWS account.

Each environment will have additional Terragrunt files corresponding to Terraform modules in `infra-modules` directory. You can check or modify module settings inside of `terragrunt.hcl` located in corresponding module directly.

### infra-modules
This directory contains Terraform modules declaring specific AWS services such as Elastic Kubernetes Service (EKS), Relational Database Service (RDS), Virtual Private Service (VPC), etc. Most of the parameters for these modules passed from Terragrunt files located in `infra-live` directory.

### applications
Kubernetes-specific declarations in YAML format that allow deployment of the scientific application containers.

## Prerequisites

Terraform state managed using AWS S3 bucket as well as Dynamo DB table. These resources should be created before the initial setup is performed in a new environment/account.

#### S3 bucket

A private S3 bucket should be created before running IaC sripts following the naming convention e.g. for production environment: 
```
twdb-production-terraform-state
```
S3 bucket should be placed in the same region as new infrastructure and have *"version control"* enabled.

#### Dynamo DB

We will need to create Dynamo DB table to provide locking of infrastructure state so it can be updated simultaneously from any location going forward. Create new table called *"terraform-lock-table"* with the following entries:
```
Partition key: LockID
```
#### Identity and Access Management (IAM)

We will need to create IAM role to let Terraform deploy to our AWS account. Create role "terraform" and assign it *`"AdministratorAccess"`* privileges. Take a note of created role ARN e.g. `arn:aws:iam::1234567890:role/terraform`

Next create new IAM policy *`"AllowTerraform"`* allowing users assume the created role:

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": "sts:AssumeRole",
            "Resource": "arn:aws:iam::1234567890:role/terraform"
        }
    ]
}
```
Lastly create an IAM group e.g. *`"DevOps"`* or use existing group and attach created *`"AllowTerraform"`* policy to the group.

# How to run

After completing all steps in [`Prerequisites`](#Prerequisites) we can start running IaC scripts.
First we need to go to the `infra-modules` directory:
```
cd infra-modules/
```
Next step is to check variables in *`terragrunt.hcl`* file. Make sure you have correct environment, AWS account and AWS region listed there:
```
locals {
    env = "production" # environment to run script
    AWS_account_number = "1234567890" # AWS account number
    region = "us-east-2" # AWS Region
}
```

Go the dedicated environment directory inside of `infra-modules` such as `production` for production environment:
```
cd production/
```
Then run Terragrunt script:
```
terrugrunt run-all init
```
You should see the following message as a result `Terraform has been successfully initialized!`

Next step is to run either plan (might fail initially) or apply for the generated files:
```
terragrunt run-all apply
```
Select `y` and watch for any errors. If deployed successfully you should see the following message: `Apply complete! Resources: 0 added, 0 changed, 0 destroyed.` there numbers will vary depending on the changes applied.

If there is no need to keep created infrastructure running we can destroy it by running:
```
terragrunt run-all destroy
```
